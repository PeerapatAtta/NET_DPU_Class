export const environment = {
    production: true,
    appName: 'Demo Web App',
    apiBaseUrl: 'https://api.demowebapp.com',
    allowedDomains: ['api.demowebapp.com']
};

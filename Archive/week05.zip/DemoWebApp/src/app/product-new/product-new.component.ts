import { Component } from '@angular/core';

@Component({
  selector: 'app-product-new',
  standalone: true,
  imports: [],
  templateUrl: './product-new.component.html',
  styleUrl: './product-new.component.css'
})
export class ProductNewComponent {

}

export interface ResetPasswordDto {
    password: string;
    confirmPassword: string;
    token: string;
    email: string;
}

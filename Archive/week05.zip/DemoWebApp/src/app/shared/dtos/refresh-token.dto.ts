export interface RefreshTokenDto {
    accessToken: string;
    refreshToken: string;
}

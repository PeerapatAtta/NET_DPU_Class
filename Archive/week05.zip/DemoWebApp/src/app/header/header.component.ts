import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { MenubarModule } from 'primeng/menubar';
import { ButtonModule } from 'primeng/button';
import { Router } from '@angular/router';
import { authKey } from '../shared/services/account.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    MenubarModule,
    ButtonModule
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {

  public get isUserLoggedIn(): boolean {
    return localStorage.getItem(authKey.accessToken) != null;
  }

  items!: MenuItem[];

  constructor(
    private router: Router) { }

  ngOnInit(): void {
    this.items = [
      {
        label: 'Product',
        items: [
          {
            label: 'All',
            routerLink: '/product/list'
          },
          {
            label: 'New',
            routerLink: '/product/new'
          }
        ]
      }
    ];
  }

  gotoLogin() {
    this.router.navigate(['/account/login']);
  }

  logout() {
    localStorage.removeItem(authKey.accessToken);
    localStorage.removeItem(authKey.refreshToken);

    this.router.navigate(['/']);
  }

}

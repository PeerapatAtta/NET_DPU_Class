import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-2YNNKRUD.js";
import "./chunk-TXRHF6LC.js";
import "./chunk-KSZJJO4I.js";
import "./chunk-X3FLC3NN.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-G7TBWI4W.js";
import "./chunk-SICFJ2I7.js";
import "./chunk-52D52JBK.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map

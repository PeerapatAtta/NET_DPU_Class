import {
  InputText,
  InputTextModule
} from "./chunk-OPKOFNAW.js";
import "./chunk-CHPTBJRE.js";
import "./chunk-G7TBWI4W.js";
import "./chunk-SICFJ2I7.js";
import "./chunk-52D52JBK.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map

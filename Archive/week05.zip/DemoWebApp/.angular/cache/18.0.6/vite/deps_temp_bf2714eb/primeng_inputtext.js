import {
  InputText,
  InputTextModule
} from "./chunk-HE6CYSSH.js";
import "./chunk-CHPTBJRE.js";
import "./chunk-SICFJ2I7.js";
import "./chunk-G7TBWI4W.js";
import "./chunk-52D52JBK.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map

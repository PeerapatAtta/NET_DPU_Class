import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-CGDBNYF4.js";
import "./chunk-TXRHF6LC.js";
import "./chunk-JUL6FIX6.js";
import "./chunk-X3FLC3NN.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-SICFJ2I7.js";
import "./chunk-G7TBWI4W.js";
import "./chunk-52D52JBK.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map

﻿namespace MonolithAPI.DTOs.Reponse;

public class TokenResultDTO
{
    public string? AccessToken { get; set; }

    public string? RefreshToken { get; set; }
}

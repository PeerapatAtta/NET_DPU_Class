﻿namespace MonolithAPI.DTOs.Reponse;

public class ProductDetailDTO : ProductDTO
{
    public string? Description { get; set; }
}

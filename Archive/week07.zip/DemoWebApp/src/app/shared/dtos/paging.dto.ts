export interface PagingDto<T> {
    totalItems: number;
    items: T[];
}

export interface TokenResultDto {
    accessToken?: string;
    refreshToken?: string;
}

export interface ProductDto {
    id: string;
    name: string;
    price: number;
    ownerName: string;
}

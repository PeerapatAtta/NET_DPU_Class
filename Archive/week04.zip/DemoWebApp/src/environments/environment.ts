export const environment = {
    production: true,
    appName: 'Demo Web App',
    apiBaseUrl: 'https://api.dpu.ac.th'
};

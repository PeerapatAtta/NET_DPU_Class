import { Routes } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import { HomeComponent } from './home/home.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductNewComponent } from './product-new/product-new.component';

export const routes: Routes = [
    {
        path: 'home',
        title: 'Home',
        component: HomeComponent
    },
    {
        path: 'product',
        title: 'Product',
        children: [
            {
                path: 'list',
                title: 'All Products',
                component: ProductListComponent
            },
            {
                path: 'new',
                title: 'New Product',
                component: ProductNewComponent
            }
        ]
    },
    {
        path: '404',
        title: 'Not Found',
        component: NotFoundComponent
    },
    {
        path: '',
        pathMatch: 'full',
        redirectTo: '/home'
    },
    {
        path: '**',
        pathMatch: 'full',
        redirectTo: '/404'
    }
];

import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-CIRCHJPE.js";
import "./chunk-UQGVZFYH.js";
import "./chunk-SICFJ2I7.js";
import "./chunk-G7TBWI4W.js";
import "./chunk-52D52JBK.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map

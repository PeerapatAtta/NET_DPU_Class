import {
  InputText,
  InputTextModule
} from "./chunk-WDWIUI34.js";
import "./chunk-UXUDH76K.js";
import "./chunk-53GRFCPY.js";
import "./chunk-CC7PZPFL.js";
import "./chunk-LGAJH4RL.js";
import "./chunk-R7GQRDZ6.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map

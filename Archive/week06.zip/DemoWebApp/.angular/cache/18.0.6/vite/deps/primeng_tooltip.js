import {
  Tooltip,
  TooltipModule
} from "./chunk-AOHB66M3.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-53GRFCPY.js";
import "./chunk-CC7PZPFL.js";
import "./chunk-LGAJH4RL.js";
import "./chunk-R7GQRDZ6.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map

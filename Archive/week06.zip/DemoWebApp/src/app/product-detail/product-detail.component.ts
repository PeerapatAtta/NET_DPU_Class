import { Component, OnInit } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ProductDetailDTO } from '../shared/dtos/product-detail.dto';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [
    CardModule,
    ButtonModule
  ],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})
export class ProductDetailComponent implements OnInit {
  product!: ProductDetailDTO;

  ngOnInit(): void {
    setTimeout(() => {
      this.product = {
        id: 'demo-id',
        name: 'Demo Product',
        price: 100.00,
        description: 'Demo product description'
      };
    }, 1500);
  }

  backClick() {

  }
}

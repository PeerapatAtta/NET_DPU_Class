export interface ForgotPasswordDTO {
    email: string;
    clientURI: string;
}

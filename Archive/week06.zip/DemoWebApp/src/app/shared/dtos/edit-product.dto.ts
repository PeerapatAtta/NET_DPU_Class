export interface EditProductDto {
    name: string;
    price: number;
    description: string;
}

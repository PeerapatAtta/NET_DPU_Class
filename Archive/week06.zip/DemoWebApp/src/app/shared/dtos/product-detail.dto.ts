export interface ProductDetailDTO {
    id: string;
    name: string;
    price: number;
    description: string;
}

import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { ProductDto } from '../dtos/product.dto';
import { environment } from '../../../environments/environment.development';
import { ProductDetailDTO } from '../dtos/product-detail.dto';
import { CreateProductDto } from '../dtos/create-product.dto';
import { EditProductDto } from '../dtos/edit-product.dto';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private http: HttpClient) { }

  getProducts() {
    let reqUrl = environment.apiBaseUrl + '/products';
    return this.http.get<ProductDto[]>(reqUrl);
  }

  getProduct(id: string) {
    let reqUrl = environment.apiBaseUrl + '/products/' + id;
    return this.http.get<ProductDetailDTO>(reqUrl);
  }

  createProduct(req: CreateProductDto) {
    let reqUrl = environment.apiBaseUrl + '/products';
    return this.http.post<ProductDetailDTO>(reqUrl, req);
  }

  editProduct(id: string, req: EditProductDto) {
    let reqUrl = environment.apiBaseUrl + '/products/' + id;
    return this.http.put<unknown>(reqUrl, req);
  }

  deleteProduct(id: string) {
    let reqUrl = environment.apiBaseUrl + '/products/' + id;
    return this.http.delete<unknown>(reqUrl);
  }
}
